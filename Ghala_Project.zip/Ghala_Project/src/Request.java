

import java.util.Date;

public class Request {
    int reqID;
        String requestType,descreption;
        Date date; 

        public Request() {}

        public Request(int reqID, String requestTyp, String descreption, Date date) {
            this.reqID = reqID;
            this.requestType = requestTyp;
            this.descreption = descreption;
            this.date = date;
        }
 
}
