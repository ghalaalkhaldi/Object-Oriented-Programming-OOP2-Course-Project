

abstract class Person {
    String Fname, Mname, Lname ,institution, country, city , specialization;//+email;
    int age;// BDate better 
    Person(){}
     Person( String Fname, String Mname, String Lname, String institution, String country, String city, int age , String specialization){
        this.Fname= Fname;
        this.Mname= Mname;
        this.Lname= Lname;
        this.age=age;
        this.institution=institution;
        this.country=country;
        this.city=city;
        this. specialization= specialization;   
    }
     void setFname(String Fname){
         this.Fname=Fname;
     }
      void setMname(String Mname){
         this.Mname=Mname;
     }
     
      void setLname(String Lname){
         this.Lname=Lname;
     }
    
     void setinstitution(String institution){
         this.institution=institution;
     }
     //SetBDate
     void setAge(int age){
         this.age=age;
     }
     
     void setCountry(String country){
         this.country=country;
     }
    
      void setCity(String city){//put it up
         this.city=city;
     }

      void Setspecialization (String specialization){
         this. specialization = specialization;
     }
    abstract String yourField(); //poly student"stud", supervisoe +المؤهل العلمي
    abstract int ID();//الفكره كانت كل مؤهل يبدا برقم معين بعدين ينعطى راندوم نمبر
    abstract boolean passwordCheck(String password);
    abstract boolean letter(char ch);
    abstract boolean numeric(char ch);
}