
import java.util.Random;

public class Investor extends Person{
        int reqId;
        Investor(){};
        Investor (String Fname, String Mname, String Lname, String institution, String country, String city, int age, String specialization,int reqId){
        super( Fname,  Mname,  Lname, institution,  country,  city,  age , specialization);
        this.reqId=reqId;
     
    }
        @Override
     int ID(){
        int start=333;
        int ranId;
        Random rand = new Random();
        int random = rand.nextInt(10000);
        String temp =(start+""+random);
        ranId= Integer.parseUnsignedInt(temp);
        return ranId;
     }
    
     @Override
     boolean passwordCheck(String password)

   {
       if (password.length()>=14) 
       return false ;

        int letterCount = 0;
        int numCount =0;
        for (int i =0; i < password.length (); i++ )
            {
               char ch = password.charAt(i);
               if (letter(ch))
               letterCount++; 
               else if (numeric(ch)) 
               numCount++;
               else 
               return false; 

               }   

    return (letterCount >= 2 || letterCount <= 4 && numCount >= 7 || numCount <= 10);
            } 
            
    @Override             
    boolean letter(char ch)
    {
         return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') ;
    }

    @Override 
    boolean numeric(char ch)
    {
        return(ch >= '0' && ch <= '9');
    }
     
     @Override
     String yourField(){
         String field="Investor";
         return field;
     }
} 
